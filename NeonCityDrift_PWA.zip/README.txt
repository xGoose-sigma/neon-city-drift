Neon City Drift Online — упаковка в APK
=======================================

Что внутри:
- index.html      — сама игра (исходник, обновлён под PWA)
- manifest.json   — манифест приложения
- sw.js           — кэш для офлайн-запуска
- icon-192.png / icon-512.png — иконки

Способ 1. Самый быстрый, без программирования (10–15 минут)
------------------------------------------------------------
1. Залейте папку целиком на GitHub (создайте репозиторий, загрузите все 5 файлов,
   включите Pages: Settings → Pages → ветка main → Save).
   Откроется адрес вида https://ваш-ник.github.io/имя-репозитория/
2. Зайдите на https://www.pwabuilder.com и вставьте этот адрес.
3. Нажмите Package for Stores → Android → Download.
4. Получите zip с APK. Файл app-release-signed.apk ставится на телефон сразу.

Способ 2. Через Android Studio (если нужен полный контроль)
------------------------------------------------------------
1. Установите Android Studio + JDK.
2. В терминале: npm i -g @capacitor/cli
3. В папке с файлами: npm init -y && npm i @capacitor/core @capacitor/cli
4. npx cap init "Neon City Drift Online" com.example.neondrift --web-dir=www
   (положите файлы игры в папку www)
5. npx cap add android && npx cap sync
6. Откройте android/ в Android Studio → Build → Generate Signed APK/BUNDLE.
7. APK появится в android/app/build/outputs/apk/release/.

Важно про игру:
- Мультиплеер работает через публичный MQTT-брокер broker.emqx.io и CDN unpkg,
  поэтому для «онлайна» нужен интернет. Сама гонка при отсутствии сети тоже
  запустится (service worker кэширует файлы).
- Идентификатор приложения com.example.neondrift можно поменять на свой.
